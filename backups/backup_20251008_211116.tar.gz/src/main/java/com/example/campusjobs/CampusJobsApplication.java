package com.example.campusjobs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusJobsApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusJobsApplication.class, args);
    }
}
