package com.example.campusjobs.model;
public enum ApplicationStatus { PENDING, APPROVED, REJECTED }
